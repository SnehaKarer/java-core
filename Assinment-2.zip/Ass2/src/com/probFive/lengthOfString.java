package com.probFive;

import java.util.Scanner;

public class lengthOfString {
	   public static void main(String[] args) {
		   Scanner scanner = new Scanner(System.in);
		           System.out.print("Enter a string: ");
		           String input = scanner.nextLine();
		    
		           // Display length of the string
		           System.out.println("Length of the string: " + input.length());
		    
		           // Convert the string to uppercase
		           String uppercaseString = input.toUpperCase();
		           System.out.println("Uppercase string: " + uppercaseString);
		    
		           // Check if the string is a palindrome
		           boolean isPalindrome = true;
		           for (int i = 0; i < input.length() / 2; i++) {
		               if (input.charAt(i) != input.charAt(input.length() - i - 1)) {
		                   isPalindrome = false;
		                   break;
		               }
		           }
		    
		           // Display whether it is a palindrome or not
		           if (isPalindrome) {
		               System.out.println("It is a Palindrome");
		           } else {
		               System.out.println("It is not a Palindrome.");
		           }
		       }
		   }


