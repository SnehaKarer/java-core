package com.books;


public class BookManager {
    public static void createBooks(String book_title, double book_price) {
        Books book = new Books(book_title, book_price);
        showBooks(book);
    }
 
    public static void showBooks(Books book) {
        System.out.println("Book_title: " + book.getBook_title() + " and Price: " + book.getBook_price());
    }
 
    public static void main(String[] args) {
        createBooks("Java Programming", 350.00);
       
    }
}