package com.Weekday;


import java.util.Scanner;

public class Weekday {
    public static void main(String[] args) {
        // Create a Scanner object to read input from the user
Scanner scanner = new Scanner(System.in);
 
        // Prompt the user to enter the week number
        System.out.print("Enter the week number: ");
        int weekNumber = scanner.nextInt();
 
        // Close the scanner
        scanner.close();
 
        // Check if the week number is within the valid range (1 to 7)
        if (weekNumber >= 1 && weekNumber <= 7) {
            // Use if-else statements to determine the weekday based on the week number
            if (weekNumber == 1) {
                System.out.println("Monday");
            } else if (weekNumber == 2) {
                System.out.println("Tuesday");
            } else if (weekNumber == 3) {
                System.out.println("Wednesday");
            } else if (weekNumber == 4) {
                System.out.println("Thursday");
            } else if (weekNumber == 5) {
                System.out.println("Friday");
            } else if (weekNumber == 6) {
                System.out.println("Saturday");
            } else if (weekNumber == 7) {
                System.out.println("Sunday");
            }
        } else {
            // Display "Invalid Input" if the week number is not within the valid range
            System.out.println("Invalid Input");
        }
    }
}