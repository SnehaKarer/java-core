package com.probFive;

public class subseqofStrring {

	public static void printSubsequences(String s) {
        printSubsequencesHelper(s, "", 0);
    }
 
    private static void printSubsequencesHelper(String s, String current, int index) {
        if (index == s.length()) {
            if (!current.isEmpty()) {
                System.out.print(current + ", ");
            }
            return;
        }
 
        printSubsequencesHelper(s, current, index + 1);
        printSubsequencesHelper(s, current + s.charAt(index), index + 1);
    }
 
    public static void main(String[] args) {
        String inputStr = "abc";
        printSubsequences(inputStr);
    }
}

