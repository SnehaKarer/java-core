package com.probFive;

import java.util.Scanner;

public class countLastNVowelss {

    public static int countLastNVowels(String str, int n) {
        int count = 0;
        int vowelCount = 0;
 
        // Count the number of vowels in the string
        for (int i = str.length() - 1; i >= 0; i--) {
            char ch = Character.toLowerCase(str.charAt(i));
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                vowelCount++;
                if (vowelCount <= n) {
                    count++;
                }
            }
        }
        return count;
    }
 
    public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        System.out.print("Enter the number of vowels to count: ");
        int n = scanner.nextInt();
 
        int lastNVowelsCount = countLastNVowels(input, n);
        if (lastNVowelsCount < n) {
            System.out.println("Mismatch in Vowel Count");
        } else {
            System.out.print("Last " + n + " vowels: ");
            for (int i = input.length() - 1; i >= 0 && n > 0; i--) {
                char ch = Character.toLowerCase(input.charAt(i));
                if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                    System.out.print(input.charAt(i));
                    n--;
                }
            }
        }
    }
}
