package com.assTwo;

import java.util.Scanner;

public class Mainn {
	
	    public static void main(String[] args) {
	    	
	        int[] A = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
	        
	        // a. Compute the sum of elements from index 0 to 14 and stores it at element 15.
	        int sum = 0;
	        for (int i = 0; i < 15; i++) {
	            sum += A[i];
	        }
	        A[15] = sum;
	        
	        // b. Compute the average of all numbers and stores it at element 16.
	        double average = (double) sum / 15;
	        A[16] = (int) average;
	        
	        // c. Identifies the smallest value from the array and stores it at element 17.
	        int min = A[0];
	        for (int i = 1; i < 15; i++) {
	            if (A[i] < min) {
	                min = A[i];
	            }
	        }
	        A[17] = min;
	        
	        // Output
	        for (int i = 0; i < A.length; i++) {
	            System.out.print(A[i] + " ");
	        }
	    }
	
	
}
